# TED Talks Corpus Transformer

This Python script (`Transformers.py`) processes the TED Talks Corpus dataset.

## Instructions:
1. Place the dataset in the `ted-talks-corpus` folder.
2. Run the script: `python Transformers.py`

## Link to models : https://iiitaphyd-my.sharepoint.com/:f:/g/personal/patanjali_b_research_iiit_ac_in/Ei29_V8cRgtGpYiD9BCQqA8B1riAooogfVWPJu0CjGXFIw?e=4unUTV

